# Worst day

local : 
1. xampp on
2. clone/download taroh di xampp/htdocs/
3. jalanin pakek command 
```bash
php -S localhost:8000
```
4. buka di browser localhost:8000

## Nambah Beban
Silahkan kalo mau pull request buat menuangkan ide UI/UX nya sob